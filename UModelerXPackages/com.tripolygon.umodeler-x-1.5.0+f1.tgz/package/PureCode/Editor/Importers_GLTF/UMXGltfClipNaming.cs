using System.IO;

namespace Tripolygon.UModelerX.Editor.Importers.GLTF
{
    /// <summary>
    /// 임포트한 클립의 이름. 애니메이션 하나짜리 glb 는 모션마다 파일을 나누는 경우가 많고 glTF 애니메이션 이름은
    /// 대개 "Animation"·"Armature|Action" 처럼 겹쳐서 Animator 에서 구분이 안 되므로 파일 이름을 쓴다.
    /// 여럿이면 파일 이름을 다 줄 수 없어 glTF 애니메이션 이름 그대로 둔다.
    /// 서브에셋 식별자는 이 이름이 아니라 glTF 애니메이션 이름으로 만든다(기존 컨트롤러 참조 유지).
    /// </summary>
    internal static class UMXGltfClipNaming
    {
        internal static string[] ResolveClipNames(string assetPath, string[] animationNames)
        {
            var names = (string[])animationNames.Clone();
            string fileName = string.IsNullOrEmpty(assetPath) ? string.Empty : Path.GetFileNameWithoutExtension(assetPath);
            if (names.Length == 1 && string.IsNullOrEmpty(fileName) == false)
            {
                names[0] = fileName;
            }
            return names;
        }
    }
}
