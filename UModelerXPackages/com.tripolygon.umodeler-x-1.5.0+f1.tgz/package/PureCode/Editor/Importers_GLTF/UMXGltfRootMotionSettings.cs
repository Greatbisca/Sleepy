namespace Tripolygon.UModelerX.Editor.Importers.GLTF
{
    /// <summary>
    /// glTF 임포트의 루트 모션 설정(임포터 인스펙터 Root Motion 섹션). 모든 클립에 같이 적용한다.
    /// </summary>
    internal sealed class UMXGltfRootMotionSettings
    {
        /// <summary>
        /// 루트 모션 노드의 임포트 결과 루트 기준 경로("Armature/Root"). 비어 있으면 루트 모션 노드 없음.
        /// Generic 결과에만 쓴다(휴머노이드는 몸 중심 루트 모션).
        /// </summary>
        public string RootMotionNode = string.Empty;

        /// <summary>
        /// Root Transform Rotation 을 포즈에 굽는다(AnimationClipSettings.loopBlendOrientation).
        /// </summary>
        public bool BakeRotation;

        /// <summary>
        /// Root Transform Position (Y) 를 포즈에 굽는다(loopBlendPositionY).
        /// </summary>
        public bool BakePositionY;

        /// <summary>
        /// Root Transform Position (XZ) 를 포즈에 굽는다(loopBlendPositionXZ).
        /// </summary>
        public bool BakePositionXZ;
    }
}
