using System.Collections.Generic;
using Tripolygon.UModelerX.Editor.Riggings;
using UnityEngine;

namespace Tripolygon.UModelerX.Editor.Importers.GLTF
{
    /// <summary>
    /// glTF 임포터 인스펙터 Root Motion 섹션의 판단(다중 선택 뼈대 비교, Root Motion Node 선택지 ↔ 저장값).
    /// 인스펙터 클래스와 떼어 두어 임포터 없이 테스트한다.
    /// </summary>
    internal static class UMXGltfRootMotionInspectorUtility
    {
        /// <summary>
        /// 저장값이 빈 문자열(루트 모션 노드 없음)일 때의 선택지. 화면에는 번역해서 보인다.
        /// </summary>
        internal const string NoneChoice = "None";

        /// <summary>
        /// 저장된 경로가 지금 계층에 없을 때 선택지 뒤에 붙인다(계층이 바뀐 glb).
        /// </summary>
        internal const string MissingSuffix = " (Missing)";

        /// <summary>
        /// 고른 임포트 결과들이 모두 같은 뼈대(루트를 뺀 하위 경로 집합이 같음)인지. null 이 섞이면 false.
        /// </summary>
        internal static bool HaveSameSkeleton(IReadOnlyList<GameObject> roots)
        {
            if (roots == null || roots.Count == 0)
            {
                return false;
            }

            HashSet<string> first = null;
            foreach (var root in roots)
            {
                if (root == null)
                {
                    return false;
                }

                var paths = new HashSet<string>(UMXGenericAvatarUtility.CollectPaths(root.transform));
                if (first == null)
                {
                    first = paths;
                }
                else if (first.SetEquals(paths) == false)
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// "None" + root 의 하위 경로 전부. 저장값 중 목록에 없는 것은 "경로 (Missing)" 으로 끝에 붙인다.
        /// </summary>
        internal static List<string> BuildRootMotionChoices(GameObject root, IEnumerable<string> savedValues)
        {
            var choices = new List<string> { NoneChoice };
            if (root != null)
            {
                choices.AddRange(UMXGenericAvatarUtility.CollectPaths(root.transform));
            }

            if (savedValues != null)
            {
                foreach (var saved in savedValues)
                {
                    if (string.IsNullOrEmpty(saved) || choices.Contains(saved))
                    {
                        continue;
                    }

                    var missing = saved + MissingSuffix;
                    if (choices.Contains(missing) == false)
                    {
                        choices.Add(missing);
                    }
                }
            }
            return choices;
        }

        /// <summary>
        /// 저장값 → 선택지. 빈 값은 None, 목록에 없으면 "(Missing)" 을 붙인다.
        /// </summary>
        internal static string ToChoice(string savedValue, IList<string> choices)
        {
            if (string.IsNullOrEmpty(savedValue))
            {
                return NoneChoice;
            }
            return choices != null && choices.Contains(savedValue) ? savedValue : savedValue + MissingSuffix;
        }

        /// <summary>
        /// 선택지 → 저장값.
        /// </summary>
        internal static string ToSavedValue(string choice)
        {
            if (string.IsNullOrEmpty(choice) || choice == NoneChoice)
            {
                return string.Empty;
            }
            return choice.EndsWith(MissingSuffix) ? choice.Substring(0, choice.Length - MissingSuffix.Length) : choice;
        }
    }
}
