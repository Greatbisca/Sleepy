﻿// glTFast 가 .glb/.gltf 의 기본 임포터로 등록되는 조건(glTFast Editor/Scripts/GltfImporter.cs 와 같은 규칙)
#if GLTFAST_PRESENT && !GLTFAST_EDITOR_IMPORT_OFF && (!GLTFAST_FORCE_DEFAULT_IMPORTER_OFF || GLTFAST_FORCE_DEFAULT_IMPORTER_ON)
#define UMX_GLTFAST_IS_DEFAULT_IMPORTER
#endif

using System;

using UnityEditor.AssetImporters;
using UnityEngine;

namespace Tripolygon.UModelerX.Editor.Importers.GLTF
{
    // 2: 좌표 변환을 z 반전 → x 반전으로 바꿨다(glTFast 와 정면 일치).
    // 3: Animation Type(Humanoid·Generic·Legacy), 블렌드쉐이프. 버전을 올려 기존 에셋을 다시 임포트한다.
    // 4: 애니메이션 하나짜리 glb 의 클립 이름을 파일 이름으로(UMXGltfClipNaming). 서브에셋 식별자는 그대로라 컨트롤러 참조는 유지된다.
    // 유니티는 한 확장자에 기본 임포터를 하나만 허용한다. glTFast 가 기본이면 우리는 대체 임포터로 등록하고(Inspector Importer 드롭다운에서 고름),
    // 새로 들어온 glb 는 UMXGltfNewAssetImporterSwitcher 가 우리 쪽으로 바꾼다.
#if UMX_GLTFAST_IS_DEFAULT_IMPORTER
    [ScriptedImporter(4, null, overrideExts: new[] { "gltf", "glb" })]
#else
    [ScriptedImporter(4, new[] { "gltf", "glb" })]
#endif
    internal sealed class UMXGltfImporter : ScriptedImporter
    {
        /// <summary>
        /// 임포트에 실패했을 때 메인 오브젝트 이름. 자동 전환이 결과를 확인할 때도 쓴다(UMXGltfImporterOverride).
        /// </summary>
        internal const string ImportFailedObjectName = "GLTF Import Failed";

        private const string HumanoidFailedMessage = "Animation Type is Humanoid, but a humanoid avatar could not be created, so the model was imported as Generic. "
            + "The required human bones (hips, spine, head, arms, hands, legs, feet) must be identifiable by bone name, have unique names, and form a valid humanoid hierarchy.";

        // 기존 에셋(meta 에 이 필드가 없음)도 재임포트 때 기본값 Auto(휴머노이드 감지 시에만 Humanoid)를 받는다.
        [SerializeField]
        private UMXGltfAnimationType animationType = UMXGltfAnimationType.Auto;

        // 루트 모션(인스펙터 Root Motion 섹션). 기존 에셋(meta 에 필드 없음)은 기본값이라 임포트 결과가 예전과 같다 — 임포터 버전은 올리지 않는다.
        // 루트 모션 노드는 임포트 결과 루트 기준 경로("Armature/Root"). 빈 값 = 없음.
        [SerializeField]
        private string rootMotionNode = string.Empty;
        [SerializeField]
        private bool bakeRootRotationIntoPose;
        [SerializeField]
        private bool bakeRootPositionYIntoPose;
        [SerializeField]
        private bool bakeRootPositionXZIntoPose;

        public override void OnImportAsset(AssetImportContext ctx)
        {
            try
            {
                var document = UMXGltfDocumentLoader.Load(ctx.assetPath);
                var assetContext = new UMXGltfAssetContext(ctx);
                var rootMotion = new UMXGltfRootMotionSettings
                {
                    RootMotionNode = rootMotionNode ?? string.Empty,
                    BakeRotation = bakeRootRotationIntoPose,
                    BakePositionY = bakeRootPositionYIntoPose,
                    BakePositionXZ = bakeRootPositionXZIntoPose,
                };
                var scene = UMXGltfSceneAssembler.Assemble(document, assetContext, animationType, rootMotion);
                // Humanoid 를 직접 골랐는데 못 만들었으면 알린다(Auto 는 조용히 Generic). 인스펙터의 임포트 경고 표시에도 나온다.
                if (animationType == UMXGltfAnimationType.Humanoid && (scene.Avatar == null || scene.Avatar.isHuman == false))
                {
                    ctx.LogImportWarning(HumanoidFailedMessage);
                }
                if (scene.RootMotionWarning != null)
                {
                    ctx.LogImportWarning(scene.RootMotionWarning);
                }

                assetContext.AddObject("main", scene.Root);
                ctx.SetMainObject(scene.Root);
            }
            catch (Exception exception)
            {
                var errorObject = new GameObject(ImportFailedObjectName);
                var assetContext = new UMXGltfAssetContext(ctx);
                assetContext.AddObject("main_error", errorObject);
                ctx.LogImportError(exception.ToString());
                ctx.SetMainObject(errorObject);
            }
        }
    }
}
