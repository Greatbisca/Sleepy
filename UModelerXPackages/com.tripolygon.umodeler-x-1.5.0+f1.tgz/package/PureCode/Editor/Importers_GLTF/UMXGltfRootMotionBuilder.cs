using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace Tripolygon.UModelerX.Editor.Importers.GLTF
{
    /// <summary>
    /// 제네릭 루트 모션 클립 만들기: 루트 노드의 Animator 루트 공간 포즈를 RootT·RootQ 커브로 넣고, 클립 루트 모션 설정을 입힌다.
    /// 유니티는 아바타 루트 노드가 지정돼 있으면 RootT·RootQ 로 오브젝트를 옮기고 루트 노드(와 조상)의 로컬은 고정한다.
    /// 그래서 RootT·RootQ 는 조상의 움직임까지 포함한 Animator 루트 공간 값이어야 오브젝트가 몸과 같이 간다(2026-11-17 실측).
    /// </summary>
    internal static class UMXGltfRootMotionBuilder
    {
        // 트랜스폼 커브 성분: 위치 xyz, 회전 xyzw, 스케일 xyz
        private static readonly string[] TransformProperties =
        {
            "m_LocalPosition.x", "m_LocalPosition.y", "m_LocalPosition.z",
            "m_LocalRotation.x", "m_LocalRotation.y", "m_LocalRotation.z", "m_LocalRotation.w",
            "m_LocalScale.x", "m_LocalScale.y", "m_LocalScale.z",
        };

        private const int ComponentCount = 10;

        /// <summary>
        /// rootNode 의 animatorRoot 기준 위치·회전을 RootT.x/y/z·RootQ.x/y/z/w 커브(경로 "", Animator)로 넣는다.
        /// 샘플 시각은 rootNode 와 그 조상(animatorRoot 아래)의 트랜스폼 커브 키 시각 합집합이고, 커브가 없는 성분은 지금 로컬 값을 쓴다.
        /// 루트 노드·조상의 트랜스폼 커브는 지우지 않는다(FBX 임포터와 같음).
        /// </summary>
        internal static void AddRootCurves(AnimationClip clip, Transform animatorRoot, Transform rootNode)
        {
            if (clip == null || animatorRoot == null || rootNode == null || rootNode == animatorRoot || rootNode.IsChildOf(animatorRoot) == false)
            {
                return;
            }

            // animatorRoot 바로 아래 조상부터 rootNode 까지
            var chain = new List<Transform>();
            for (var current = rootNode; current != animatorRoot; current = current.parent)
            {
                chain.Add(current);
            }
            chain.Reverse();

            var chainIndexByPath = new Dictionary<string, int>();
            for (int i = 0; i < chain.Count; ++i)
            {
                chainIndexByPath[AnimationUtility.CalculateTransformPath(chain[i], animatorRoot)] = i;
            }

            var curves = new AnimationCurve[chain.Count, ComponentCount];
            var keyTimes = new SortedSet<float>();
            foreach (var binding in AnimationUtility.GetCurveBindings(clip))
            {
                if (binding.type != typeof(Transform) || chainIndexByPath.TryGetValue(binding.path, out int chainIndex) == false)
                {
                    continue;
                }

                int component = System.Array.IndexOf(TransformProperties, binding.propertyName);
                if (component < 0)
                {
                    continue;
                }

                var curve = AnimationUtility.GetEditorCurve(clip, binding);
                if (curve == null)
                {
                    continue;
                }

                curves[chainIndex, component] = curve;
                foreach (var key in curve.keys)
                {
                    keyTimes.Add(key.time);
                }
            }

            // 루트 노드·조상이 안 움직이면 상수 커브(클립 처음과 끝)
            if (keyTimes.Count == 0)
            {
                keyTimes.Add(0f);
                if (clip.length > 0f)
                {
                    keyTimes.Add(clip.length);
                }
            }

            var times = new float[keyTimes.Count];
            keyTimes.CopyTo(times);
            var values = new float[7][];
            for (int i = 0; i < values.Length; ++i)
            {
                values[i] = new float[times.Length];
            }

            var previousRotation = Quaternion.identity;
            for (int frame = 0; frame < times.Length; ++frame)
            {
                float time = times[frame];
                var matrix = Matrix4x4.identity;
                var rotation = Quaternion.identity;
                for (int i = 0; i < chain.Count; ++i)
                {
                    var node = chain[i];
                    var localPosition = new Vector3(
                        Evaluate(curves[i, 0], time, node.localPosition.x),
                        Evaluate(curves[i, 1], time, node.localPosition.y),
                        Evaluate(curves[i, 2], time, node.localPosition.z));
                    var localRotation = Normalize(new Quaternion(
                        Evaluate(curves[i, 3], time, node.localRotation.x),
                        Evaluate(curves[i, 4], time, node.localRotation.y),
                        Evaluate(curves[i, 5], time, node.localRotation.z),
                        Evaluate(curves[i, 6], time, node.localRotation.w)));
                    var localScale = new Vector3(
                        Evaluate(curves[i, 7], time, node.localScale.x),
                        Evaluate(curves[i, 8], time, node.localScale.y),
                        Evaluate(curves[i, 9], time, node.localScale.z));

                    matrix *= Matrix4x4.TRS(localPosition, localRotation, localScale);
                    // 유니티 월드 회전처럼 스케일과 무관하게 로컬 회전만 곱한다
                    rotation *= localRotation;
                }

                // 프레임 사이 쿼터니언 부호가 뒤집히면 보간이 긴 호로 돈다
                if (frame > 0 && Quaternion.Dot(previousRotation, rotation) < 0f)
                {
                    rotation = new Quaternion(-rotation.x, -rotation.y, -rotation.z, -rotation.w);
                }
                previousRotation = rotation;

                var position = matrix.MultiplyPoint3x4(Vector3.zero);
                values[0][frame] = position.x;
                values[1][frame] = position.y;
                values[2][frame] = position.z;
                values[3][frame] = rotation.x;
                values[4][frame] = rotation.y;
                values[5][frame] = rotation.z;
                values[6][frame] = rotation.w;
            }

            clip.SetCurve(string.Empty, typeof(Animator), "RootT.x", BuildLinearCurve(times, values[0]));
            clip.SetCurve(string.Empty, typeof(Animator), "RootT.y", BuildLinearCurve(times, values[1]));
            clip.SetCurve(string.Empty, typeof(Animator), "RootT.z", BuildLinearCurve(times, values[2]));
            clip.SetCurve(string.Empty, typeof(Animator), "RootQ.x", BuildLinearCurve(times, values[3]));
            clip.SetCurve(string.Empty, typeof(Animator), "RootQ.y", BuildLinearCurve(times, values[4]));
            clip.SetCurve(string.Empty, typeof(Animator), "RootQ.z", BuildLinearCurve(times, values[5]));
            clip.SetCurve(string.Empty, typeof(Animator), "RootQ.w", BuildLinearCurve(times, values[6]));
        }

        /// <summary>
        /// Bake Into Pose 3개를 클립에 입힌다. keepOriginal 이면 Based Upon 을 셋 다 Original 로 둔다(제네릭).
        /// FBX 기본값(Rotation false·Y true·XZ false)은 루트 노드 조상에 회전이 있으면 이동 방향이 그만큼 돌아간다(2026-11-17 실측).
        /// keepOriginal 이 아니면 Based Upon 은 그대로 둔다(휴머노이드는 베이커가 둔 값).
        /// </summary>
        internal static void ApplyClipSettings(AnimationClip clip, UMXGltfRootMotionSettings settings, bool keepOriginal)
        {
            if (clip == null || settings == null)
            {
                return;
            }

            var clipSettings = AnimationUtility.GetAnimationClipSettings(clip);
            clipSettings.loopBlendOrientation = settings.BakeRotation;
            clipSettings.loopBlendPositionY = settings.BakePositionY;
            clipSettings.loopBlendPositionXZ = settings.BakePositionXZ;
            if (keepOriginal)
            {
                clipSettings.keepOriginalOrientation = true;
                clipSettings.keepOriginalPositionY = true;
                clipSettings.keepOriginalPositionXZ = true;
            }
            AnimationUtility.SetAnimationClipSettings(clip, clipSettings);
        }

        private static float Evaluate(AnimationCurve curve, float time, float restValue)
        {
            return curve != null ? curve.Evaluate(time) : restValue;
        }

        private static Quaternion Normalize(Quaternion rotation)
        {
            float magnitude = Mathf.Sqrt(rotation.x * rotation.x + rotation.y * rotation.y + rotation.z * rotation.z + rotation.w * rotation.w);
            if (magnitude < 1e-6f)
            {
                return Quaternion.identity;
            }
            return new Quaternion(rotation.x / magnitude, rotation.y / magnitude, rotation.z / magnitude, rotation.w / magnitude);
        }

        // 키 사이는 선형(인접 키 기울기를 양쪽 탄젠트로 공유). 키가 하나면 상수.
        private static AnimationCurve BuildLinearCurve(float[] times, float[] values)
        {
            var keys = new Keyframe[times.Length];
            for (int i = 0; i < times.Length; ++i)
            {
                keys[i] = new Keyframe(times[i], values[i]);
            }

            for (int i = 0; i + 1 < keys.Length; ++i)
            {
                float deltaTime = keys[i + 1].time - keys[i].time;
                if (deltaTime > 0f)
                {
                    float slope = (keys[i + 1].value - keys[i].value) / deltaTime;
                    keys[i].outTangent = slope;
                    keys[i + 1].inTangent = slope;
                }
            }

            return new AnimationCurve(keys);
        }
    }
}
