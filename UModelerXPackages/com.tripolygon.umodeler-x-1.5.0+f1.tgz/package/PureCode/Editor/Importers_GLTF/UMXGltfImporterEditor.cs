using UnityEditor;
using UnityEditor.AssetImporters;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

namespace Tripolygon.UModelerX.Editor.Importers.GLTF
{
    /// <summary>
    /// glTF 임포터 인스펙터. Animation Type 아래에 마지막 임포트가 실제로 만든 리그(Humanoid·Generic·Legacy·None)를 보여 준다.
    /// Auto 가 휴머노이드를 감지했는지, Humanoid 가 실패해 Generic 이 됐는지를 여기서 확인한다.
    /// </summary>
    [CustomEditor(typeof(UMXGltfImporter))]
    [CanEditMultipleObjects]
    internal sealed class UMXGltfImporterEditor : ScriptedImporterEditor
    {
        internal const string HumanoidRigName = "Humanoid";
        internal const string GenericRigName = "Generic";
        internal const string LegacyRigName = "Legacy";
        internal const string NoRigName = "None";

        // 여러 에셋을 골랐는데 결과가 서로 다를 때(유니티 혼합 값 표시와 같은 줄표)
        private const string MixedRigText = "—";
        private const long RefreshIntervalMilliseconds = 500;

        // UMXGltfImporter 직렬화 필드 이름
        private const string AnimationTypeProperty = "animationType";
        private const string RootMotionNodeProperty = "rootMotionNode";
        private const string BakeRotationProperty = "bakeRootRotationIntoPose";
        private const string BakePositionYProperty = "bakeRootPositionYIntoPose";
        private const string BakePositionXZProperty = "bakeRootPositionXZIntoPose";
        // 유니티 [Header] 와 같은 모양의 내장 클래스
        private const string HeaderLabelClass = "unity-header-drawer__label";

        private TextField importedRigField;
        private VisualElement rootMotionSection;
        private PopupField<string> rootMotionNodeField;
        private PropertyField[] bakeFields;

        public override VisualElement CreateInspectorGUI()
        {
            var root = new VisualElement();
            root.Add(new PropertyField(this.serializedObject.FindProperty(AnimationTypeProperty), UMXLocalization.Tr("Animation Type")));

            // 값은 드롭다운 항목 이름과 같게 영어 그대로 둔다
            this.importedRigField = new TextField(UMXLocalization.Tr("Imported Rig"));
            this.importedRigField.AddToClassList(TextField.alignedFieldUssClassName);
            this.importedRigField.SetEnabled(false);
            root.Add(this.importedRigField);

            BuildRootMotionSection(root);

            RefreshImportedRig();
            RefreshRootMotion();
            // Apply 로 다시 임포트해도 이 트리가 다시 만들어진다는 보장이 없어 주기적으로 다시 읽는다
            this.importedRigField.schedule.Execute(() =>
            {
                RefreshImportedRig();
                RefreshRootMotion();
            }).Every(RefreshIntervalMilliseconds);

            // 2022.3 에는 UI Toolkit 용 Apply/Revert 요소가 없다(ApplyRevertButtonContainer 는 6000 대부터). IMGUI 버튼을 그대로 얹는다.
            root.Add(new IMGUIContainer(ApplyRevertGUI));
            return root;
        }

        /// <summary>
        /// Root Motion 섹션: 헤더, Root Motion Node 드롭다운(임포트 결과 계층의 경로), Bake Into Pose 3개(모든 클립 공통).
        /// </summary>
        private void BuildRootMotionSection(VisualElement root)
        {
            this.rootMotionSection = new VisualElement();
            var header = new Label(UMXLocalization.Tr("Root Motion"));
            header.AddToClassList(HeaderLabelClass);
            this.rootMotionSection.Add(header);

            // 선택지는 갱신 때 채운다. 경로는 영어 그대로, None 만 번역해서 보인다
            System.Func<string, string> format = choice => choice == UMXGltfRootMotionInspectorUtility.NoneChoice ? UMXLocalization.Tr("None") : choice;
            this.rootMotionNodeField = new PopupField<string>(UMXLocalization.Tr("Root Motion Node"),
                new System.Collections.Generic.List<string> { UMXGltfRootMotionInspectorUtility.NoneChoice }, 0, format, format);
            this.rootMotionNodeField.AddToClassList(BaseField<string>.alignedFieldUssClassName);
            this.rootMotionNodeField.RegisterValueChangedCallback(OnRootMotionNodeChanged);
            this.rootMotionSection.Add(this.rootMotionNodeField);

            this.bakeFields = new[]
            {
                new PropertyField(this.serializedObject.FindProperty(BakeRotationProperty), UMXLocalization.Tr("Bake Rotation Into Pose")),
                new PropertyField(this.serializedObject.FindProperty(BakePositionYProperty), UMXLocalization.Tr("Bake Position Y Into Pose")),
                new PropertyField(this.serializedObject.FindProperty(BakePositionXZProperty), UMXLocalization.Tr("Bake Position XZ Into Pose")),
            };
            foreach (var field in this.bakeFields)
            {
                this.rootMotionSection.Add(field);
            }

            root.Add(this.rootMotionSection);
        }

        private void OnRootMotionNodeChanged(ChangeEvent<string> evt)
        {
            var property = this.serializedObject.FindProperty(RootMotionNodeProperty);
            if (property == null)
            {
                return;
            }

            // 다중 선택이면 고른 에셋 전부에 쓴다. Apply 를 눌러야 다시 임포트된다
            this.serializedObject.Update();
            property.stringValue = UMXGltfRootMotionInspectorUtility.ToSavedValue(evt.newValue);
            this.serializedObject.ApplyModifiedProperties();
            this.rootMotionNodeField.showMixedValue = false;
        }

        /// <summary>
        /// Root Motion 섹션 표시·활성 상태와 Root Motion Node 선택지를 지금 설정·임포트 결과에 맞춘다.
        /// 섹션은 클립이 있는 에셋을 골랐고 Animation Type 이 Legacy 가 아닐 때, 노드 줄은 고른 에셋이 모두 같은 뼈대일 때만 보인다.
        /// </summary>
        private void RefreshRootMotion()
        {
            if (this.rootMotionSection == null)
            {
                return;
            }

            this.serializedObject.Update();
            var animationType = this.serializedObject.FindProperty(AnimationTypeProperty);
            var rootMotionNode = this.serializedObject.FindProperty(RootMotionNodeProperty);
            if (animationType == null || rootMotionNode == null)
            {
                return;
            }

            bool typeMixed = animationType.hasMultipleDifferentValues;
            int type = animationType.intValue;
            bool legacy = typeMixed == false && type == (int)UMXGltfAnimationType.Legacy;
            bool sectionVisible = legacy == false && HasAnimationClips();
            this.rootMotionSection.style.display = sectionVisible ? DisplayStyle.Flex : DisplayStyle.None;
            if (sectionVisible == false)
            {
                return;
            }

            var roots = GetImportedRoots();
            bool nodeVisible = roots != null && UMXGltfRootMotionInspectorUtility.HaveSameSkeleton(roots);
            this.rootMotionNodeField.style.display = nodeVisible ? DisplayStyle.Flex : DisplayStyle.None;
            if (nodeVisible)
            {
                var choices = UMXGltfRootMotionInspectorUtility.BuildRootMotionChoices(roots[0], new[] { rootMotionNode.stringValue });
                if (this.rootMotionNodeField.choices == null || System.Linq.Enumerable.SequenceEqual(this.rootMotionNodeField.choices, choices) == false)
                {
                    this.rootMotionNodeField.choices = choices;
                }
                this.rootMotionNodeField.SetValueWithoutNotify(UMXGltfRootMotionInspectorUtility.ToChoice(rootMotionNode.stringValue, choices));
                this.rootMotionNodeField.showMixedValue = rootMotionNode.hasMultipleDifferentValues;

                // 휴머노이드 루트 모션은 몸 중심 기준이라 루트 노드를 쓰지 않는다
                bool humanoid = typeMixed == false && type == (int)UMXGltfAnimationType.Humanoid;
                this.rootMotionNodeField.SetEnabled(humanoid == false);
                this.rootMotionNodeField.tooltip = humanoid ? UMXLocalization.Tr("Humanoid avatars use the body center for root motion.") : string.Empty;
            }

            // Generic 인데 루트 모션 노드가 없으면 루트 커브가 없어 Bake 가 의미 없다
            bool genericWithoutNode = typeMixed == false && type == (int)UMXGltfAnimationType.Generic
                && rootMotionNode.hasMultipleDifferentValues == false && string.IsNullOrEmpty(rootMotionNode.stringValue);
            foreach (var field in this.bakeFields)
            {
                field.SetEnabled(genericWithoutNode == false);
            }
        }

        // 고른 에셋 중 하나라도 애니메이션 클립 서브에셋이 있는지
        private bool HasAnimationClips()
        {
            foreach (var target in this.targets)
            {
                var importer = target as AssetImporter;
                if (importer == null)
                {
                    continue;
                }

                foreach (var asset in AssetDatabase.LoadAllAssetRepresentationsAtPath(importer.assetPath))
                {
                    if (asset is AnimationClip)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        // 고른 에셋들의 임포트 결과 루트. 하나라도 없거나 임포트 실패 오브젝트면 null
        private System.Collections.Generic.List<GameObject> GetImportedRoots()
        {
            var assets = this.assetTargets;
            if (assets == null || assets.Length == 0)
            {
                return null;
            }

            var roots = new System.Collections.Generic.List<GameObject>(assets.Length);
            foreach (var asset in assets)
            {
                var root = asset as GameObject;
                if (root == null || root.name == UMXGltfImporter.ImportFailedObjectName)
                {
                    return null;
                }
                roots.Add(root);
            }
            return roots;
        }

        private void RefreshImportedRig()
        {
            if (this.importedRigField == null)
            {
                return;
            }

            string rigName = null;
            var assets = this.assetTargets;
            if (assets != null)
            {
                foreach (var asset in assets)
                {
                    var current = GetImportedRigName(asset as GameObject);
                    if (rigName == null)
                    {
                        rigName = current;
                    }
                    else if (rigName != current)
                    {
                        rigName = MixedRigText;
                        break;
                    }
                }
            }

            this.importedRigField.SetValueWithoutNotify(rigName ?? string.Empty);
        }

        /// <summary>
        /// 임포트 결과 루트에 붙은 컴포넌트로 리그 종류를 읽는다(UMXGltfSceneAssembler 가 붙이는 규칙과 짝).
        /// 임포트 실패 오브젝트면 빈 문자열.
        /// </summary>
        internal static string GetImportedRigName(GameObject root)
        {
            if (root == null || root.name == UMXGltfImporter.ImportFailedObjectName)
            {
                return string.Empty;
            }
            if (root.GetComponent<Animation>() != null)
            {
                return LegacyRigName;
            }

            var animator = root.GetComponent<Animator>();
            if (animator == null)
            {
                return NoRigName;
            }
            return animator.avatar != null && animator.avatar.isHuman ? HumanoidRigName : GenericRigName;
        }
    }
}
