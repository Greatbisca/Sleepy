using Tripolygon.UModelerX.Editor.Riggings;
using UnityEngine;

namespace Tripolygon.UModelerX.Editor.Importers.GLTF
{
    internal sealed class UMXGltfAssembledScene
    {
        public GameObject Root;
        public AnimationClip[] Clips;
        /// <summary>
        /// 만든 아바타(휴머노이드, 또는 Root Motion Node 를 지정한 제네릭). 없으면 null.
        /// </summary>
        public Avatar Avatar;
        /// <summary>
        /// 루트 모션 설정을 다 적용하지 못한 이유(영어, 임포터가 임포트 경고로 남긴다). 없으면 null.
        /// </summary>
        public string RootMotionWarning;
    }

    /// <summary>
    /// 불러온 glTF 문서로 임포트 결과(계층·메시·머티리얼·클립·아바타)를 만들고 서브에셋으로 등록한다.
    /// ScriptedImporter 없이도(standalone 문맥) 같은 결과를 만들어 테스트할 수 있게 임포터 본문에서 떼어 두었다.
    /// </summary>
    internal static class UMXGltfSceneAssembler
    {
        internal static UMXGltfAssembledScene Assemble(UMXGltfLoadedDocument document, UMXGltfAssetContext assetContext, UMXGltfAnimationType animationType)
        {
            return Assemble(document, assetContext, animationType, new UMXGltfRootMotionSettings());
        }

        internal static UMXGltfAssembledScene Assemble(UMXGltfLoadedDocument document, UMXGltfAssetContext assetContext, UMXGltfAnimationType animationType,
            UMXGltfRootMotionSettings rootMotion)
        {
            rootMotion = rootMotion ?? new UMXGltfRootMotionSettings();
            var materialBuilder = new UMXGltfMaterialBuilder(document, assetContext);
            var meshBuilder = new UMXGltfMeshBuilder(document, assetContext, materialBuilder);
            var builtMeshes = meshBuilder.BuildAll();
            var nodeBuilder = new UMXGltfNodeBuilder(document, builtMeshes);
            var rootObject = nodeBuilder.BuildSceneRoot();
            bool hasSkin = rootObject.GetComponentInChildren<SkinnedMeshRenderer>(true) != null;

            // Auto 는 스킨이 있을 때만 휴머노이드를 시도한다. 필수 본이 모자라거나 아바타가 유효하지 않으면 경고 없이 Generic 으로 만든다.
            // Humanoid 는 스킨이 없어도 시도한다. 실패하면 똑같이 Generic 으로 만들고, 경고는 임포터가 남긴다(Avatar == null 로 판단).
            Avatar avatar = null;
            if (animationType == UMXGltfAnimationType.Humanoid || (animationType == UMXGltfAnimationType.Auto && hasSkin))
            {
                UMXGltfHumanoidBuilder.TryBuildAvatar(rootObject, rootObject.name + "Avatar", out avatar);
            }

            var animationBuilder = new UMXGltfAnimationBuilder(document, assetContext, nodeBuilder.NodePaths, nodeBuilder.MorphBindings)
            {
                Legacy = animationType == UMXGltfAnimationType.Legacy,
                // 휴머노이드는 일반 클립을 굽는 재료로만 쓰고, 구운 클립을 같은 키로 등록한다
                RegisterAssets = avatar == null,
            };
            var clips = animationBuilder.BuildAll();
            // 서브에셋 식별자는 glTF 애니메이션 이름으로 둔다(위에서 등록, 휴머노이드는 아래에서 같은 키로). 보이는 클립 이름만 바꾼다(UMXGltfClipNaming)
            var animationNames = new string[clips.Length];
            for (int i = 0; i < clips.Length; ++i)
            {
                animationNames[i] = clips[i].name;
            }
            var clipNames = UMXGltfClipNaming.ResolveClipNames(document.AssetPath, animationNames);
            for (int i = 0; i < clips.Length; ++i)
            {
                clips[i].name = clipNames[i];
            }
            var scene = new UMXGltfAssembledScene { Root = rootObject, Clips = clips, Avatar = avatar };

            if (animationType == UMXGltfAnimationType.Legacy)
            {
                AttachAnimationComponent(rootObject, clips);
                return scene;
            }

            if (avatar != null)
            {
                assetContext.AddObject("Avatar", avatar);
                for (int i = 0; i < clips.Length; ++i)
                {
                    var baked = UMXHumanoidClipBaker.BakeClip(rootObject, avatar, clips[i]);
                    Object.DestroyImmediate(clips[i]);
                    clips[i] = baked;
                    // 휴머노이드 루트 모션은 몸 중심 기준이라 Root Motion Node 는 쓰지 않고 Bake 만 입힌다
                    UMXGltfRootMotionBuilder.ApplyClipSettings(baked, rootMotion, false);
                    assetContext.AddObject(animationNames[i], baked);
                }

                rootObject.AddComponent<Animator>().avatar = avatar;
                return scene;
            }

            // Generic(직접 고른 것, 또는 Auto 가 휴머노이드를 못 만든 것)만 루트 노드를 쓴다. Humanoid 를 골랐다가 실패한 것은 경고로 끝낸다.
            Avatar genericAvatar = null;
            if ((animationType == UMXGltfAnimationType.Generic || animationType == UMXGltfAnimationType.Auto) && string.IsNullOrEmpty(rootMotion.RootMotionNode) == false)
            {
                genericAvatar = BuildRootMotionAvatar(rootObject, clips, rootMotion, assetContext, scene);
            }

            // Animator 는 움직일 것(스킨·클립)이나 루트 모션 아바타가 있을 때만 붙인다. 정적 모델은 예전처럼 컴포넌트가 없다.
            if (clips.Length > 0 || hasSkin || genericAvatar != null)
            {
                rootObject.AddComponent<Animator>().avatar = genericAvatar;
            }

            return scene;
        }

        /// <summary>
        /// Root Motion Node 로 제네릭 아바타를 만들고, 클립마다 RootT·RootQ 와 Bake·Based Upon(Original) 을 넣는다.
        /// 노드를 못 찾거나 아바타를 못 만들면 scene.RootMotionWarning 을 남기고 null(루트 모션 없이 예전처럼 임포트).
        /// </summary>
        private static Avatar BuildRootMotionAvatar(GameObject rootObject, AnimationClip[] clips, UMXGltfRootMotionSettings rootMotion,
            UMXGltfAssetContext assetContext, UMXGltfAssembledScene scene)
        {
            string path = rootMotion.RootMotionNode;
            var node = rootObject.transform.Find(path);
            if (node == null || node == rootObject.transform)
            {
                scene.RootMotionWarning = $"Root Motion Node '{path}' was not found, so the model was imported without root motion.";
                return null;
            }

            // 유니티는 루트 노드를 이름으로 찾으므로 이름이 겹치면 다른 노드가 잡힐 수 있다
            if (UMXGenericAvatarUtility.CountNamed(rootObject.transform, node.name) > 1)
            {
                scene.RootMotionWarning = $"More than one node is named '{node.name}'. Unity finds the root motion node by name, so root motion may follow a different node. Give the root motion node a unique name.";
            }

            var avatar = UMXGenericAvatarUtility.Build(rootObject, node.name);
            if (avatar == null)
            {
                scene.RootMotionWarning = $"A generic avatar could not be created for Root Motion Node '{path}', so the model was imported without root motion.";
                return null;
            }

            assetContext.AddObject("Avatar", avatar);
            foreach (var clip in clips)
            {
                if (clip == null)
                {
                    continue;
                }

                UMXGltfRootMotionBuilder.AddRootCurves(clip, rootObject.transform, node);
                UMXGltfRootMotionBuilder.ApplyClipSettings(clip, rootMotion, true);
            }

            scene.Avatar = avatar;
            return avatar;
        }

        // legacy Animation 컴포넌트의 path 기반 curve binding 은 glTF channel 의 (node, path) 모델과 자연스럽게
        // 매칭된다. clip.legacy = true 인 clip 만 AddClip 가능 — AnimationBuilder 에서 보장.
        private static void AttachAnimationComponent(GameObject rootObject, AnimationClip[] clips)
        {
            if (clips == null || clips.Length == 0)
            {
                return;
            }

            var animationComponent = rootObject.AddComponent<Animation>();
            foreach (var clip in clips)
            {
                if (clip == null)
                {
                    continue;
                }

                animationComponent.AddClip(clip, clip.name);
            }

            animationComponent.clip = clips[0];
            animationComponent.playAutomatically = false;
        }
    }
}
