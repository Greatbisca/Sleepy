namespace Tripolygon.UModelerX.Editor.Importers.GLTF
{
    /// <summary>
    /// glTF 임포트의 리그·애니메이션 형식(FBX 임포터 Rig 탭의 Animation Type 과 같은 역할). 직렬화 값이라 숫자를 바꾸지 않는다.
    /// </summary>
    internal enum UMXGltfAnimationType
    {
        /// <summary>
        /// 휴머노이드 골격이 감지되면 휴머노이드 아바타 + 휴머노이드 클립, 아니면 Generic(경고 없음).
        /// 감지 = 스킨이 있고, 본 이름으로 필수 휴먼 본을 다 찾고(계층도 맞고), 유니티가 유효한 휴머노이드 아바타를 만든다.
        /// 예전 이름은 Humanoid 였다 — 모든 glb 가 Humanoid 로 보여서 바꿨다. 값 0 의 동작은 같다.
        /// </summary>
        Auto = 0,

        /// <summary>
        /// 스킨이 없어도 항상 휴머노이드를 시도한다. 실패하면 Generic 으로 만들고 임포트 경고를 남긴다.
        /// 드롭다운이 선언 순서라 Auto 다음에 둔다(값은 뒤에 추가한 3).
        /// </summary>
        Humanoid = 3,

        /// <summary>
        /// Animator + 일반(legacy 아님) 클립.
        /// </summary>
        Generic = 1,

        /// <summary>
        /// Animation 컴포넌트 + legacy 클립(예전 동작).
        /// </summary>
        Legacy = 2,
    }
}
